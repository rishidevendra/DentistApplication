﻿

module service {
    'use strict';

    export class dentistService {
        static toString = "dentistService";
        static $inject = [
            "$q",
            "$http"
        ];

        constructor(
            private $q: ng.IQService,
            private $http: ng.IHttpService
            ) {
            console.log("Constructor - DentistService");
        }
        public removeDoctorData(selectedRow) {
            var doctorId = selectedRow.DoctorId;
            return this.deleteRequest("/api/Doctors/" + doctorId);
        }
        public GetDentistData() {
            console.log("Inside GetDentistData service function");
            var request = {};
            return this.getRequest("/api/Doctors/", request);
        }

        private deleteRequest<T>(partUri: string): ng.IPromise {
            var deferred = this.$q.defer();
            var uri = ".";
            this.$http
                .delete(uri + partUri, {
                    headers: {
                    }
                })
                .success((response, status) => {
                    console.log("Post" + partUri + "success");
                    deferred.resolve(response);
                })
                .error((data, status, header, config) => {
                    console.log("Post" + partUri + "error");
                    deferred.reject(data);
                });
            return deferred.promise;
        }

        private getRequest<T>(partUri: string, request: T): ng.IPromise {
            var deferred = this.$q.defer();
            var uri = ".";
            this.$http
                .get(uri + partUri, {
                    headers: {
                    }
                })
                .success((response, status) => {
                    console.log("Post" + partUri + "success");
                    deferred.resolve(response);
                })
                .error((data, status, header, config) => {
                    console.log("Post" + partUri + "error");
                    deferred.reject(data);
                });
            return deferred.promise;
        }
    }
}

module filter {
    'use strict';
    export class wrapText {
        static toString = "wrapText";
        static filterFactory() {
            return (text: string, length) => {
                if (!text) { return '' };
                var value = text.toString().trim();
                var wrappedtext: string = "";
                var textMaxLength = length - 3;
                wrappedtext = value;
                if (wrappedtext.length <= length) {
                    return wrappedtext;
                }
                else {
                    return wrappedtext.substring(0, textMaxLength) + "...";
                }
            };
        }
    }

}

module Html {
    'use strict';
    export interface dentistScope extends ng.IScope {
        GetDentistData: () => void;
        rowCollection: any;
        itemsByPage: number;
        rowSelected: (selectedData) => void;
        selectedData: any;
        deleteDoctor: () => void;
        checkBoxClicked: () => void;
        isSelectedRow: boolean;
        refreshGrid: () => void;
    }

    export class dentistModel {
    }
    export class dentistController {
        static toString = "dentistController";
        static $inject = [
            "$scope",
            "$http",
            "$filter",
            service.dentistService.toString
        ];
        private model = new dentistModel();
        constructor(
            private $scope: dentistScope,
            private $http: ng.IHttpService,
            private $filter: ng.IFilterProvider,
            private dentistService: service.dentistService
            ) {
            console.log("Constructor - DentistController");
            $scope.GetDentistData = () => this.GetDentistData();
            $scope.rowCollection = [];
            $scope.itemsByPage = 3;
            $scope.deleteDoctor = () => this.deleteDoctor();
            $scope.rowSelected = (selectedData) => this.rowSelected(selectedData);
            $scope.checkBoxClicked = () => this.checkBoxClicked();
            $scope.isSelectedRow = false;
            $scope.refreshGrid = () => this.refreshGrid();
        }
        private refreshGrid() {
            this.GetDentistData();
        }
        private checkBoxClicked() {
            if (this.$scope.isSelectedRow == true) {
                //for (var i = 0; i < this.$scope.rowCollection.length; i++) {
                //    alert(this.$scope.rowCollection[i].isSelected);
                //}
                this.$scope.rowCollection = this.$scope.rowCollection;
            }

        }
        public rowSelected(selectedData) {           
            if (this.$scope.isSelectedRow == true) {
                selectedData.isSelected = false;
                return;
            }
            this.$scope.selectedData = selectedData;
        }
       
        public deleteDoctor() {
            console.log("Inside Removing doctor");
            if (this.$scope.selectedData) {
                this.dentistService.removeDoctorData(this.$scope.selectedData).then((result) => {
                    this.$scope.rowCollection = result;
                    this.$scope.$apply();
                },
                    (error) => {
                        console.log("error occured while deleting record");
                    });
            }
            else {
                alert("Please select the item before click on Delete button");
            }
        }
        public GetDentistData() {
            console.log("Inside GetDentistData function");
            this.dentistService.GetDentistData().then((result) => {
                console.log("received success API response");
                this.$scope.rowCollection = result;
            },
                (error) => {
                    console.log("received error from API");
                });
        }
    }
}



module main {
    'use strict';
    var appModule = angular.module("app", ['smart-table'])
        .controller(Html.dentistController.toString, Html.dentistController)
        .service(service.dentistService.toString, service.dentistService)
        .filter(filter.wrapText.toString, filter.wrapText.filterFactory);
}



