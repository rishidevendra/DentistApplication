/// <reference path="../../_references.d.ts" />
var Html;
(function (Html) {
    'use strict';
    var dentistModel = (function () {
        function dentistModel() {
        }
        return dentistModel;
    })();
    Html.dentistModel = dentistModel;
    var dentistController = (function () {
        function dentistController($scope, $http) {
            this.$scope = $scope;
            this.$http = $http;
            this.model = new dentistModel();
            console.log("Constructor - DentistController");
        }
        dentistController.prototype.GetDentistData = function () {
        };
        dentistController.toString = "dentistController";
        dentistController.$inject = [
            "$scope",
            "$http"
        ];
        return dentistController;
    })();
    Html.dentistController = dentistController;
})(Html || (Html = {}));
/// <reference path="../../_references.d.ts" />
//module service {
//    'use strict';
//    export class dentistService {
//        static toString = "dentistService";
//        static $inject = [
//            "$http"
//        ];
//        constructor(
//            private $http: ng.IHttpService
//            ) {
//            console.log("Constructor - DentistService");
//        }
//       public  GetDentistData() {
//            console.log("Inside GetDentistData service function");
//        }
//    }
//}
//module Html {
//    'use strict';
//    export interface dentistScope {
//    }
//    export class dentistModel {
//    }
//    export class dentistController {
//        static toString = "dentistController";
//        static $inject = [
//            "$scope",
//            "$http",
//            service.dentistService.toString
//        ];
//        private model = new dentistModel();
//        constructor(
//            private $scope: ng.IScope,
//            private $http: ng.IHttpService,
//            private dentistService : service.dentistService
//            ) {
//            console.log("Constructor - DentistController");
//        }
//       public GetDentistData() {
//            console.log("Inside GetDentistData function");
//            this.dentistService.GetDentistData();
//        }
//    }
//}
var main;
(function (main) {
    'use strict';
    var appModule = angular.module("app", []).controller(Html.dentistController.toString, Html.dentistController);
})(main || (main = {}));
