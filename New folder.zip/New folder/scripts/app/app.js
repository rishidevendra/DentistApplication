var service;
(function (service) {
    'use strict';
    var dentistService = (function () {
        function dentistService($q, $http) {
            this.$q = $q;
            this.$http = $http;
            console.log("Constructor - DentistService");
        }
        dentistService.prototype.removeDoctorData = function (selectedRow) {
            var doctorId = selectedRow.DoctorId;
            return this.deleteRequest("/api/Doctors/" + doctorId);
        };
        dentistService.prototype.GetDentistData = function () {
            console.log("Inside GetDentistData service function");
            var request = {};
            return this.getRequest("/api/Doctors/", request);
        };
        dentistService.prototype.deleteRequest = function (partUri) {
            var deferred = this.$q.defer();
            var uri = ".";
            this.$http
                .delete(uri + partUri, {
                headers: {}
            })
                .success(function (response, status) {
                console.log("Post" + partUri + "success");
                deferred.resolve(response);
            })
                .error(function (data, status, header, config) {
                console.log("Post" + partUri + "error");
                deferred.reject(data);
            });
            return deferred.promise;
        };
        dentistService.prototype.getRequest = function (partUri, request) {
            var deferred = this.$q.defer();
            var uri = ".";
            this.$http
                .get(uri + partUri, {
                headers: {}
            })
                .success(function (response, status) {
                console.log("Post" + partUri + "success");
                deferred.resolve(response);
            })
                .error(function (data, status, header, config) {
                console.log("Post" + partUri + "error");
                deferred.reject(data);
            });
            return deferred.promise;
        };
        dentistService.toString = "dentistService";
        dentistService.$inject = [
            "$q",
            "$http"
        ];
        return dentistService;
    }());
    service.dentistService = dentistService;
})(service || (service = {}));
var filter;
(function (filter) {
    'use strict';
    var wrapText = (function () {
        function wrapText() {
        }
        wrapText.filterFactory = function () {
            return function (text, length) {
                if (!text) {
                    return '';
                }
                ;
                var value = text.toString().trim();
                var wrappedtext = "";
                var textMaxLength = length - 3;
                wrappedtext = value;
                if (wrappedtext.length <= length) {
                    return wrappedtext;
                }
                else {
                    return wrappedtext.substring(0, textMaxLength) + "...";
                }
            };
        };
        wrapText.toString = "wrapText";
        return wrapText;
    }());
    filter.wrapText = wrapText;
})(filter || (filter = {}));
var Html;
(function (Html) {
    'use strict';
    var dentistModel = (function () {
        function dentistModel() {
        }
        return dentistModel;
    }());
    Html.dentistModel = dentistModel;
    var dentistController = (function () {
        function dentistController($scope, $http, $filter, dentistService) {
            var _this = this;
            this.$scope = $scope;
            this.$http = $http;
            this.$filter = $filter;
            this.dentistService = dentistService;
            this.model = new dentistModel();
            console.log("Constructor - DentistController");
            $scope.GetDentistData = function () { return _this.GetDentistData(); };
            $scope.rowCollection = [];
            $scope.itemsByPage = 3;
            $scope.deleteDoctor = function () { return _this.deleteDoctor(); };
            $scope.rowSelected = function (selectedData) { return _this.rowSelected(selectedData); };
            $scope.checkBoxClicked = function () { return _this.checkBoxClicked(); };
            $scope.isSelectedRow = false;
            $scope.refreshGrid = function () { return _this.refreshGrid(); };
        }
        dentistController.prototype.refreshGrid = function () {
            this.GetDentistData();
        };
        dentistController.prototype.checkBoxClicked = function () {
            if (this.$scope.isSelectedRow == true) {
                //for (var i = 0; i < this.$scope.rowCollection.length; i++) {
                //    alert(this.$scope.rowCollection[i].isSelected);
                //}
                this.$scope.rowCollection = this.$scope.rowCollection;
            }
        };
        dentistController.prototype.rowSelected = function (selectedData) {
            if (this.$scope.isSelectedRow == true) {
                selectedData.isSelected = false;
                return;
            }
            this.$scope.selectedData = selectedData;
        };
        dentistController.prototype.deleteDoctor = function () {
            var _this = this;
            console.log("Inside Removing doctor");
            if (this.$scope.selectedData) {
                this.dentistService.removeDoctorData(this.$scope.selectedData).then(function (result) {
                    _this.$scope.rowCollection = result;
                    _this.$scope.$apply();
                }, function (error) {
                    console.log("error occured while deleting record");
                });
            }
            else {
                alert("Please select the item before click on Delete button");
            }
        };
        dentistController.prototype.GetDentistData = function () {
            var _this = this;
            console.log("Inside GetDentistData function");
            this.dentistService.GetDentistData().then(function (result) {
                console.log("received success API response");
                _this.$scope.rowCollection = result;
            }, function (error) {
                console.log("received error from API");
            });
        };
        dentistController.toString = "dentistController";
        dentistController.$inject = [
            "$scope",
            "$http",
            "$filter",
            service.dentistService.toString
        ];
        return dentistController;
    }());
    Html.dentistController = dentistController;
})(Html || (Html = {}));
var main;
(function (main) {
    'use strict';
    var appModule = angular.module("app", ['smart-table'])
        .controller(Html.dentistController.toString, Html.dentistController)
        .service(service.dentistService.toString, service.dentistService)
        .filter(filter.wrapText.toString, filter.wrapText.filterFactory);
})(main || (main = {}));
