/// <reference path="../../_references.d.ts" />
//module Html {
//    'use strict';
//    export interface dentistScope {
//    }
//    export class dentistModel {
//    }
//    export class dentistController {
//        static toString = "dentistController";
//        static $inject = [
//            "$scope",
//            "$http"
//        ];
//        private model = new dentistModel();
//        constructor(
//            private $scope: ng.IScope,
//            private $http: ng.IHttpService
//            ) {
//            console.log("Constructor - DentistController");
//        }
//        GetDentistData() {
//        }
//    }
//} 
